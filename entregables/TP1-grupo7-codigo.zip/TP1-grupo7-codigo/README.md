# TP1 — Código

**Grupo 7** — Andrés Cortese (64612) · Sebastián Caules (64331)
72.75 Aprendizaje Automático (Machine Learning) — ITBA — 2026 Q2

Regresión lineal y polinómica sobre el dataset **Insurance Charges**, evaluadas con
*k-fold cross-validation*. Todo corre con **numpy, pandas y matplotlib** (Python 3.10+).

**No usa scikit-learn**: el punto 2.2 del enunciado pide *implementar* el esquema de
validación cruzada, así que el split train/test, el k-fold, la codificación one-hot, el
estandarizado, la resolución por mínimos cuadrados, la expansión polinómica y el Lasso por
descenso por coordenadas están escritos desde cero sobre numpy. Los tests tampoco usan
pytest: cada suite se corre como módulo.

## Cómo correrlo

```bash
pip install numpy pandas matplotlib

# Tests: corren en segundos y no dependen de nada más.
python -m tests.test_validacion
python -m tests.test_preproceso
python -m tests.test_modelos
python -m tests.test_paleta

# Punto 1 — análisis exploratorio (sólo sobre train, no toca test).
python -m src.datos

# Puntos 2 a 5 — CV, grados 1 a 4, barrido de lambda y evaluación final.
# Tarda unos 27 minutos: el Lasso de grado 4 son 1364 features casi colineales.
# Crea resultados/ y escribe ahí todos los CSV y JSON.
python -m src.experimentos
```

`src.experimentos` es el que **recrea los resultados**. Una vez que corrió, el resto lee de
`resultados/`:

```bash
python -m src.evidencia_features     # evidencia numérica de las features derivadas
python -m src.diagnostico_residuos   # dónde vive el error que queda
python -m src.sensibilidad_k         # barrido del número de folds
python -m src.graficos               # figuras -> figuras/
python -m src.tablas                 # tablas LaTeX -> informe/
```

Ninguno de estos cinco toca el conjunto de test.

## Qué hay en cada archivo

```
src/datos.py           punto 1 — evidencia de cada decisión de limpieza y construcción de
                       las tres features derivadas (fumador_obeso, edad_al_cuadrado,
                       bmi_si_fuma). cargar_train() devuelve sólo las 1070 filas de train
src/validacion.py      rmse, r2, split train/test, k-fold, resumen entre folds
src/preproceso.py      codificación one-hot, estandarizado, expansión polinómica
src/modelos.py         OLS por mínimos cuadrados vía SVD, ridge, Lasso por coordenadas
src/experimentos.py    puntos 2 a 5 — CV, grados 1-4, barrido de lambda, test final
src/evaluar_test.py    evaluación única sobre test, con el modelo ya elegido
src/evidencia_features.py  evidencia numérica de las features derivadas y de children
src/diagnostico_residuos.py  descomposición del error que queda
src/sensibilidad_k.py  barrido del número de folds k
src/graficos.py        figuras del informe y de la presentación
src/graficos_presentacion.py  los cuadros armados para las slides
src/tablas.py          genera las tablas LaTeX desde resultados/*.csv

tests/                 suites con casos de respuesta conocida, sin pytest
                       (test_paleta valida los colores de las figuras bajo simulación
                       de las cuatro visiones de daltonismo)

data/raw/insurance.csv el dataset, copiado tal cual se descargó de Kaggle
                       (1338 filas × 7 columnas)
```

## El resultado

Modelo de producción: **regresión lineal de grado 1, sin regularizar, once características**.
RMSE de test **4288,52 dólares**, R² **0,871**, contra 11963,43 del baseline trivial de
predecir siempre la media. El test son 267 filas reservadas desde el principio, que no
participaron de ninguna decisión —ni siquiera del análisis exploratorio— y se evaluaron
una sola vez.

La semilla está fijada en 42 en todo el pipeline, así que los números se reproducen exactos.
