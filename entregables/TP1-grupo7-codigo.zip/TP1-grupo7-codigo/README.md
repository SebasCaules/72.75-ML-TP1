# TP1 — Regresión e introducción a la evaluación de modelos

**Grupo 7** — Andrés Cortese (64612) · Sebastián Caules (64331)
**72.75 Aprendizaje Automático (Machine Learning) — ITBA — 2026 Q2**
Defensa: 02/09/2026, 17:35, Aula 701F

Predicción del costo anual de gastos médicos (`charges`) del dataset **Insurance Charges**
(punto 0.2 del enunciado) mediante regresión lineal y polinómica, evaluadas con *k-fold
cross-validation*.

**Resultado: RMSE de 4288,52 dólares en test** (R² = 0,871), con un modelo lineal de grado 1
y once características, sin regularizar.

---

## Qué hay acá adentro

```
README.md              este archivo
src/                   12 módulos: el pipeline completo
tests/                 4 suites con casos de respuesta conocida
data/raw/              insurance.csv, tal cual se descargó de Kaggle (1338 filas × 7 columnas)
```

Es sólo el código necesario para correr el pipeline y **recrear los resultados desde cero**,
más los tests. No vienen las figuras ni los CSV/JSON de resultados porque los **produce el
propio código**: `python -m src.experimentos` crea `resultados/` y lo llena, y
`python -m src.graficos` crea `figuras/`.

### `src/` — los doce módulos

| Archivo | Qué hace |
|---|---|
| `datos.py` | Punto 1. La evidencia de cada decisión de limpieza y la construcción de las tres características derivadas. `cargar_train()` es la puerta de entrada: devuelve **sólo** las 1070 filas de train |
| `validacion.py` | `rmse`, `r2`, `separar_train_test`, `k_fold`, `resumen_folds` |
| `preproceso.py` | `CodificadorCategoricas` (one-hot), `Estandarizador`, `expandir_polinomica`, `quitar_duplicados` |
| `modelos.py` | `RegresionLineal` (mínimos cuadrados vía SVD), ridge, `Lasso` por descenso por coordenadas |
| `experimentos.py` | Puntos 2 a 5: CV, grados 1 a 4, barrido de λ y selección del modelo |
| `evaluar_test.py` | La evaluación **única** sobre test, con el modelo ya elegido |
| `evidencia_features.py` | La evidencia numérica de las features derivadas, de la estratificación y de `children` |
| `diagnostico_residuos.py` | Dónde vive el error que queda |
| `sensibilidad_k.py` | Barrido del número de folds *k* |
| `graficos.py` | Las figuras del informe y de la presentación |
| `graficos_presentacion.py` | Los cuadros armados para las slides |
| `tablas.py` | Genera las tablas LaTeX desde `resultados/*.csv` |

De estos, **sólo `evaluar_test.py` toca el conjunto de test**. Todo el resto trabaja
exclusivamente sobre las 1070 filas de train.

### `tests/` — las cuatro suites

| Archivo | Qué verifica |
|---|---|
| `test_validacion.py` | `rmse` y `r2` contra valores calculados a mano; que el k-fold parta sin solapamiento y cubra todo |
| `test_preproceso.py` | Que `expandir_polinomica` dé las columnas correctas para grados 1 a 4, y que los nombres coincidan |
| `test_modelos.py` | Que el Lasso con λ→0 converja a OLS, que anule features irrelevantes, y que su objetivo J(w) **no aumente** entre barridas |
| `test_paleta.py` | Que los colores de las figuras superen 3:1 de contraste y sigan distinguiéndose bajo las cuatro simulaciones de daltonismo |

No usan pytest: cada suite se corre como módulo y termina imprimiendo `TODOS LOS TESTS OK`.

---

## Cómo correrlo

Requiere **Python 3.10+** y sólo **numpy, pandas y matplotlib**.

**No usa scikit-learn.** El punto 2.2 pide *implementar* el esquema de validación cruzada, así
que el split train/test, el k-fold, la codificación one-hot, el estandarizado, la resolución
por mínimos cuadrados, la expansión polinómica y el Lasso por descenso por coordenadas están
escritos desde cero sobre numpy.

```bash
pip install numpy pandas matplotlib

# Tests: corren en segundos y no dependen de nada más.
python -m tests.test_validacion
python -m tests.test_preproceso
python -m tests.test_modelos
python -m tests.test_paleta

# Punto 1 — análisis exploratorio, sólo sobre train.
python -m src.datos

# Puntos 2 a 5 — recrea resultados/ desde cero.
# Tarda unos 27 minutos: el Lasso de grado 4 son 1364 features casi colineales
# y el descenso por coordenadas necesita decenas de miles de barridas.
python -m src.experimentos
```

Una vez que `src.experimentos` corrió, el resto lee de `resultados/`:

```bash
python -m src.evidencia_features     # evidencia de las features derivadas
python -m src.diagnostico_residuos   # descomposición del error que queda
python -m src.sensibilidad_k         # barrido del número de folds
python -m src.graficos               # figuras -> figuras/
python -m src.tablas                 # tablas LaTeX -> informe/
```

La semilla está fijada en **42** en todo el pipeline, así que los números se reproducen exactos.

---

## Dónde se resuelve cada punto del enunciado

| Punto | Dónde |
|---|---|
| 1.1 Variables categóricas (one-hot) | `datos.analizar_categoricas()` · `preproceso.CodificadorCategoricas` |
| 1.2 Valores faltantes | `datos.analizar_faltantes()` — el dataset no tiene, y queda documentado |
| 1.3 Outliers | `datos.analizar_outliers()`, con `outliers_iqr()` y `outliers_zscore()` para contrastar criterios · `datos.perfil_de_outliers()` |
| 1.4 Características y escalado | `datos.agregar_derivadas()` · `preproceso.Estandarizador` · `datos.escalas()` |
| 2.1 Separación train/test | `validacion.separar_train_test()` |
| 2.2 k-fold cross-validation | `validacion.k_fold()` · `validacion.resumen_folds()` |
| 2.3 Entrenamiento lineal + RMSE | `modelos.RegresionLineal` · `validacion.rmse()` · `experimentos.py` |
| 3.1 Transformación polinómica | `preproceso.expandir_polinomica()` |
| 3.2 Entrenamiento sobre las transformadas | `experimentos.py` |
| 3.3 Regularización L1 | `modelos.Lasso` · `modelos.lambda_maximo()` |
| 4. Evaluación por grado y λ | `experimentos.py` → `resultados/cv_lineal.csv` y `cv_lasso.csv` |
| 5. Comparación y modelo elegido | `experimentos.py` → `resultados/modelo_elegido.json` · `evaluar_test.py` → `evaluacion_test.json` |

---

## El resultado

Validación cruzada de 5 folds sobre las 1070 filas de train. Todo el preproceso —codificación,
escalado y expansión polinómica— se ajusta **dentro de cada fold**, sobre el train del fold, y
recién después se aplica al de validación.

| Modelo | Grado | λ | RMSE train | RMSE validación | Features |
|---|---:|---:|---:|---:|---:|
| **lineal** | **1** | **—** | 4351,6 ± 93,2 | **4413,4 ± 367,0** | **11** |
| lineal | 2 | — | 4227,2 ± 104,7 | 4516,7 ± 380,0 | 77 |
| lineal | 3 | — | 3931,1 ± 117,1 | 6757,5 ± 857,0 | 363 |
| lineal | 4 | — | 3379,1 ± 105,3 | **87916,9 ± 47000,1** | 1364 |
| lasso | 2 | 103,6 | 4330,4 ± 89,2 | 4422,9 ± 360,3 | 22,2 de 77 |

El grado 4 sin regularizar es el retrato del sobreajuste: **el mejor error de train de toda la
tabla** y un error de validación veinte veces peor que el del grado 1, con un desvío entre folds
ciento veintiocho veces más grande. No es sólo peor: es inestable.

| | features | RMSE test | R² test |
|---|---:|---:|---:|
| **Modelo de producción** (lineal, grado 1, sin regularizar) | **11** | **4288,52** | **0,871** |
| Baseline trivial (predecir siempre la media) | — | 11963,43 | 0,000 |

El test son 267 filas reservadas desde el principio, que no participaron de ninguna decisión
—ni siquiera del análisis exploratorio— y se evaluaron **una sola vez**. El RMSE de test queda
124,93 dólares *por debajo* del de validación cruzada: nada indica que el modelo generalice peor
de lo que promete la validación.

### El hallazgo

Lo que más mueve el error no es un modelo más complejo sino **una columna nueva**. `bmi`
correlaciona apenas 0,194 con `charges`, pero su efecto depende de si la persona fuma: la
obesidad encarece un 11 % a los no fumadores y un **95 %** a los fumadores. Y es un **escalón**,
no una pendiente — casi quince mil dólares en una unidad de bmi alrededor de 30.

Un término polinómico `bmi × smoker` modela un cambio de pendiente y no puede representar un
salto, así que el pipeline agrega la binaria `fumador_obeso = (smoker=yes) ∧ (bmi > 30)`. El
umbral 30 es el de la OMS, una constante médica externa al dataset, no el corte que minimiza el
error (el barrido lo confirma igual). El mismo método dio `edad_al_cuadrado` y `bmi_si_fuma`.

Con esas tres características incluidas, ni la expansión polinómica ni la regularización bajan
el error: por eso gana el modelo más simple del espacio de búsqueda.
